#ifndef _DHT_11_H_
#define _DHT_11_H_
#include "bsp_iic.h"
#include <rtthread.h>
#include <rtdevice.h>
#include "uc_gpio.h"

#define DHT11_High 1
#define DHT11_Low 0

#define RESET 0
#define SET 1
#define SUCCESS 1
#define DHT11_CLK RCC_AHB1Periph_GPIOE
#define DHT11_PIN GPIO_PIN_3
#define DHT11_PORT UC_GPIO
#define DHT11_GPIO_CFG UC_GPIO_CFG
#define DHT11_DATA_OUT(a) if(a)\
        gpio_set_pin_value(DHT11_PORT,DHT11_PIN,GPIO_VALUE_HIGH);\
        else\
        gpio_set_pin_value(DHT11_PORT,DHT11_PIN,GPIO_VALUE_LOW);

// #define DHT11_DATA_IN() GPIO_ReadInputDataBit(DHT11_PORT,DHT11_PIN)
#define DHT11_DATA_IN() gpio_get_pin_value(DHT11_PORT,DHT11_PIN)
typedef struct 
{
    uint8_t humi_int;// ʪ����������
    uint8_t humi_deci;//ʪ��С������
    uint8_t temp_int;//�¶���������
    uint8_t temp_deci;//�¶�С������
    uint8_t check_sum;//У��λ��ǰ�ĸ�����֮��
}DHT11_DATA_TypeDef;

void DHT11_GPIO_Config(void);
uint8_t DHT11_Read(DHT11_DATA_TypeDef *DHT11_DATA);

#endif /* _DHT_11_H_ */
