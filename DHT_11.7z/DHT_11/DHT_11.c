#include "DHT_11.h"

#define DHT11_Delay_ms(x) Delay_ms(x)
#define DHT11_Delay_10us(x) Delay_10us(x)
//��ʼ��GPIO ʱ��-50Mhz-���-����-����
void DHT11_GPIO_Config(void) 
{
    gpio_set_pin_pupd(DHT11_GPIO_CFG,DHT11_PIN,GPIO_PUPD_UP);
    gpio_set_pin_direction(DHT11_PORT,DHT11_PIN,GPIO_DIR_OUT);
    rt_kprintf("DHT11_GPIO_Config OK\n");
    
}

static void DHT11_GPIO_Input(void)
{
    // GPIO_InitTypeDef GPIO_InitStruct;
    // GPIO_InitStruct.GPIO_Pin = DHT11_PIN;
    // GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    // GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
    // // GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    // GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
    // GPIO_Init(DHT11_PORT,&GPIO_InitStruct);
    gpio_set_pin_pupd(DHT11_GPIO_CFG,DHT11_PIN,GPIO_PUPD_NONE);
    gpio_set_pin_direction(DHT11_PORT,DHT11_PIN,GPIO_DIR_IN);
    rt_kprintf("DHT11 DATA Input\n");
}

static void DHT11_GPIO_Output(void)
{
    gpio_set_pin_pupd(UC_GPIO_CFG,DHT11_PIN,GPIO_PUPD_UP);
    gpio_set_pin_direction(DHT11_PORT,DHT11_PIN,GPIO_DIR_OUT);
}

static uint8_t DHT11_Read_Byte(void)
{
    uint8_t i,temp=0;
    for(i=0; i<8; i++)
    {
        while(DHT11_DATA_IN()==RESET);


        DHT11_Delay_10us(4);
        if(DHT11_DATA_IN()==SET)
        {
            while(DHT11_DATA_IN()==SET);
            temp |= (uint8_t)(0x01<<(7-i));
        }
        else 
            temp &= (uint8_t)~(0x01<<(7-i));
    }
    return temp;
}

uint8_t DHT11_Read(DHT11_DATA_TypeDef *DHT11_DATA)
{
    rt_kprintf("DHT11_Read Begin\n");
    uint16_t count;
    DHT11_GPIO_Output();
    rt_kprintf("DHT11 Output Set\n");

    DHT11_DATA_OUT(DHT11_Low);
    rt_kprintf("DHT11 Output LOW\n");
    Delay_ms(20);
    rt_kprintf("DHT11 Output HIGH\n");
    DHT11_DATA_OUT(DHT11_High);
    DHT11_Delay_10us(3);

    DHT11_GPIO_Input();
    if(DHT11_DATA_IN())
    rt_kprintf("DHT11 IN Set\n");
    else
    rt_kprintf("DHT11 IN RESet\n");
    if(DHT11_DATA_IN()==RESET)
    {
        count = 0;
        while(DHT11_DATA_IN()==RESET)
        {
            count++;
            if(count>1000)
            {
                rt_kprintf("DHT11 READ RESET OVERTIME\n");
                return 0;
            }
            DHT11_Delay_10us(1);
        }
        count = 0;
        while(DHT11_DATA_IN()==SET)
        {
            count++;
            if(count>1000)
            {
                rt_kprintf("DHT11 READ SET OVERTIME\n");
                return 0;
            }
            DHT11_Delay_10us(1);
        }

        DHT11_DATA->humi_int = DHT11_Read_Byte();
        DHT11_DATA->humi_deci = DHT11_Read_Byte();
        DHT11_DATA->temp_int = DHT11_Read_Byte();
        DHT11_DATA->temp_deci = DHT11_Read_Byte();
        DHT11_DATA->check_sum = DHT11_Read_Byte();

		DHT11_GPIO_Output();
		DHT11_DATA_OUT(DHT11_High);

        if(DHT11_DATA->check_sum==DHT11_DATA->humi_deci+DHT11_DATA->humi_int+DHT11_DATA->temp_int+DHT11_DATA->temp_deci)
        return 1;
        else
        {
            rt_kprintf("DHT11 WRITE ERROR");
            return 0;
        }
    }
    else
    {
        rt_kprintf("DHT11 NOT GET INPUT\n");
        return 0;
    }
}




