#include "bsp_iic.h"
#include "uc_gpio.h"

//��ʼ�� GPIO 
void I2C_Init(GPIO_TypeDef* GPIO, GPIO_CFG_TypeDef* GPIO_CFG, GPIO_PIN scl_pin, GPIO_PIN sda_pin) 
{
    //SCL����
    gpio_set_pin_direction(GPIO, scl_pin, GPIO_DIR_OUT);
    gpio_set_pin_pupd(GPIO_CFG, scl_pin, GPIO_PUPD_UP);
    //SDA����
    gpio_set_pin_direction(GPIO, sda_pin, GPIO_DIR_OUT);
    gpio_set_pin_pupd(GPIO_CFG, sda_pin, GPIO_PUPD_UP);
}

//I2C Start 
void I2C_Start(GPIO_TypeDef* GPIO, GPIO_PIN scl_pin, GPIO_PIN sda_pin) 
{
    
    gpio_set_pin_direction(GPIO, sda_pin, GPIO_DIR_OUT);
    gpio_set_pin_value(GPIO, sda_pin, GPIO_VALUE_LOW);
    Delay_10us(I2C_DELAY);

    gpio_set_pin_direction(GPIO, scl_pin, GPIO_DIR_OUT);
    gpio_set_pin_value(GPIO, scl_pin, GPIO_VALUE_HIGH);
    Delay_10us(I2C_DELAY);

    gpio_set_pin_value(GPIO, sda_pin, GPIO_VALUE_HIGH);
    Delay_10us(I2C_DELAY);
}

//I2C Stop
void I2C_Stop(GPIO_TypeDef* GPIO, GPIO_PIN scl_pin, GPIO_PIN sda_pin) 
{
    
    gpio_set_pin_direction(GPIO, sda_pin, GPIO_DIR_OUT);
    gpio_set_pin_value(GPIO, sda_pin, GPIO_VALUE_LOW);
    Delay_10us(I2C_DELAY);
    gpio_set_pin_direction(GPIO, scl_pin, GPIO_DIR_OUT);
    gpio_set_pin_value(GPIO, scl_pin, GPIO_VALUE_HIGH);
    Delay_10us(I2C_DELAY);
    gpio_set_pin_direction(GPIO, sda_pin, GPIO_DIR_OUT);
    gpio_set_pin_value(GPIO, sda_pin, GPIO_VALUE_HIGH);
    Delay_10us(I2C_DELAY);
}

// I2C Write one Byte 
void I2C_WriteByte(GPIO_TypeDef* GPIO, GPIO_PIN scl_pin, GPIO_PIN sda_pin, uint8_t data) 
{
    
    gpio_set_pin_direction(GPIO, sda_pin, GPIO_DIR_OUT);

    for (uint8_t i = 0; i < 8; i++) {
        gpio_set_pin_value(GPIO, scl_pin, GPIO_VALUE_LOW);
        Delay_10us(I2C_DELAY);
        gpio_set_pin_value(GPIO, sda_pin, (data & (1 << (7-i))) ? GPIO_VALUE_HIGH : GPIO_VALUE_LOW);
        Delay_10us(I2C_DELAY);
        gpio_set_pin_value(GPIO, scl_pin, GPIO_VALUE_HIGH);
        Delay_10us(I2C_DELAY);
    }

    gpio_set_pin_value(GPIO, scl_pin, GPIO_VALUE_LOW);

    Delay_10us(I2C_DELAY);
}

//I2C Read One Byte
uint8_t I2C_ReadByte(GPIO_TypeDef* GPIO, GPIO_PIN scl_pin, GPIO_PIN sda_pin) 
{    
    uint8_t data = 0;
    gpio_set_pin_direction(GPIO, sda_pin, GPIO_DIR_OUT);
    for (uint8_t i = 0; i < 8; i++) {
        gpio_set_pin_value(GPIO, scl_pin, GPIO_VALUE_LOW);
        Delay_10us(I2C_DELAY);
        gpio_set_pin_value(GPIO, scl_pin, GPIO_VALUE_HIGH);
        Delay_10us(I2C_DELAY);
        data |= gpio_get_pin_value(GPIO, sda_pin) << (7-i);
    }
    gpio_set_pin_direction(GPIO, sda_pin, GPIO_DIR_OUT);
    gpio_set_pin_value(GPIO, scl_pin, GPIO_VALUE_LOW);
    Delay_10us(I2C_DELAY);
    return data;
}


