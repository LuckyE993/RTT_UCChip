#ifndef _BSP_IIC_H_
#define _BSP_IIC_H_
#include <rtthread.h>
#include <rtdevice.h>
#include "uc_gpio.h"
#include "bsp_timer.h"

#define I2C_DELAY 1 
#define I2C_ACK 0   
#define I2C_NACK 1  

void I2C_Init(GPIO_TypeDef* GPIO, GPIO_CFG_TypeDef* GPIO_CFG, GPIO_PIN scl_pin, GPIO_PIN sda_pin);
void I2C_Start(GPIO_TypeDef* GPIO, GPIO_PIN scl_pin, GPIO_PIN sda_pin);
void I2C_Stop(GPIO_TypeDef* GPIO, GPIO_PIN scl_pin, GPIO_PIN sda_pin);
void I2C_WriteByte(GPIO_TypeDef* GPIO, GPIO_PIN scl_pin, GPIO_PIN sda_pin, uint8_t data);
uint8_t I2C_ReadByte(GPIO_TypeDef* GPIO, GPIO_PIN scl_pin, GPIO_PIN sda_pin);

#endif /* _BSP_IIC_H_ */
